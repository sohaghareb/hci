package hcipackage;
//package hci;

public enum State {
Collapsed,Uncollapsed,Hidden,Unhidden,Zipped,Navigate,default_state
}
